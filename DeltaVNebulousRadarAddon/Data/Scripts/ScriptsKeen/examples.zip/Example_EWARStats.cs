﻿using System.Collections.Generic;
using VRage.Game;
using VRage.Game.Components;
using NerdRadar.Definitions;
using Sandbox.ModAPI;
using VRageMath;

namespace NerdRadar.ExampleMod
{
    [MySessionComponentDescriptor(MyUpdateOrder.NoUpdate)]
    public class Example_EWARStats : MySessionComponentBase
    {
        BlockConfig cfg => new BlockConfig()
        {
            // Feel free to change the Example_EWARStats to something else, along with the namespace (NerdRadar.ExampleMod)
            // Aside from those, do not change anything above this line

            // Stats for all the radar blocks. How stats interact can be found here http://nebfltcom.wikidot.com/mechanics:radar
            // RCS is calculated via (LG blockcount * 0.25)^2*2.5+(SG blockcount * 0.25)^2*0.01+(Generated power in MW) * 0.5
            RadarStats = new Dictionary<string, RadarStat>()
            {
                ["Nerd_Radar"] = new RadarStat()
                {
                    MaxRadiatedPower = 2500, // radiated power of the radar, in kilowatts
                    Gain = 30, // gain of the radar, in decibels. Must be above 0
                    Sensitivity = -36, // sensitivity of the radar, in decibels
                    MaxSearchRange = 40000, // maximum range radar will return targets, regardless of other settings, in meters

                    ApertureSize = 40, // aperture size of the radar, in meters^2
                    NoiseFilter = 0, // noise filter of the radar, in decibels
                    SignalToNoiseRatio = 1, // ratio of return signal to noise required for the radar to detect targets

                    PositionError = 70, // maximum error of position in any given direction the radar returns in meters
                    VelocityError = 5, // maximum error in the velocity vector in any given direction the radar returns (velocity indicator coming soonTM)

                    CanTargetLock = true, // determines whether or not the radar can lock. Locked targets have no velocity and position error, and will have the radar detected icon turn red from yellow.
                                          // more functionality coming soonTM
                    LOSCheckIncludesParentGrid = false,
                                          // determines whether the radar's LOS check will include the grid it is on. Useful for radar paneling and such. Subgrids attached to the main grid count as the main grid in this case.
                    StealthMultiplier = 1, // if the target is cloaked via the Stealth Drive mod (https://steamcommunity.com/sharedfiles/filedetails/?id=2805859069), then the target's RCS is multiplied by this when the radar scans.

                    CanDetectAllJumps = true, // Determines if the radar can detect and show any jumps caused by any track visible to the radar.
                    CanDetectLockedJumps = false, // Determines if the radar can detect and show any jumps caused by the tracked locked by the radar.
                },
                // other radar examples below, copied from Nerd's mod that uses this
                ["Nerd_Radar_Basic"] = new RadarStat()
                {
                    MaxRadiatedPower = 1500,
                    Gain = 25,
                    Sensitivity = -36,
                    MaxSearchRange = 10000,

                    ApertureSize = 40,
                    NoiseFilter = 0,
                    SignalToNoiseRatio = 1,

                    PositionError = 100,
                    VelocityError = 5,

                    CanTargetLock = true,
                    LOSCheckIncludesParentGrid = false,

                    StealthMultiplier = 0,

                    CanDetectAllJumps = false,
                    CanDetectLockedJumps = false,
                },
                ["Nerd_Radar_SG"] = new RadarStat()
                {
                    MaxRadiatedPower = 1400,
                    Gain = 35,
                    Sensitivity = -36,
                    MaxSearchRange = 10000,

                    ApertureSize = 25,
                    NoiseFilter = 0,
                    SignalToNoiseRatio = 1,

                    PositionError = 100,
                    VelocityError = 5,

                    CanTargetLock = false,
                    LOSCheckIncludesParentGrid = false,

                    StealthMultiplier = 0,

                    CanDetectAllJumps = false,
                    CanDetectLockedJumps = true,
                },
                ["EyeOfSauron"] = new RadarStat() // I SEE YOU
                {
                    MaxRadiatedPower = 50000,
                    Gain = 30,
                    Sensitivity = -40,
                    MaxSearchRange = 100000,

                    ApertureSize = 100,
                    NoiseFilter = 0,
                    SignalToNoiseRatio = 1,

                    PositionError = 0.01f,
                    VelocityError = 0,

                    CanTargetLock = true,
                    LOSCheckIncludesParentGrid = true,

                    StealthMultiplier = 1,

                    CanDetectAllJumps = true,
                    CanDetectLockedJumps = false,
                },
            },
            // stats for all the jammer blocks
            // stat interactions can be found here http://nebfltcom.wikidot.com/mechanics:electronic-warfare
            JammerStats = new Dictionary<string, JammerStat>()
            {
                ["Nerd_JammingBlock"] = new JammerStat()
                {
                    MaxRadiatedPower = 1, // max radiated power in kilowatts
                    Gain = 10, // gain of the jammer in decibels
                    MaxSearchRange = 45000, // maximum range of the jammer in meters, overriding ALL other stats

                    AreaEffectRatio = 0.4f, // Area effect ratio of the jammer. Best explained in the interaction wiki above.
                                            // Essentually, when a radar is jammed, a cylinder of height =2*(the distance from the jammer) and radius of AreaEffectRatio*length centered on the jammer, with the top and bottom being on the line between the radar and jammer

                    AngleRadians = MathHelperD.ToRadians(25), // angle from the center muzzle of the jammer that ships within are jammed, in radians (keep the MathHelper.ToRadians(value) call if you want to use degrees)
                    LOSCheckIncludesParentGrid = true, // Determines whether the jammer can jam through its own grid.

                    MaxHeat = 90 * 60, // maximum heat the jammer can handle before shutting off. Heat will always increase by 1 every tick. Measured in ProprietaryHeatUnitTM
                                       // set to -1 to disable
                                       // heat on a GUI somewhere coming soonTM
                    HeatDrainPerTick = 1.5f, // Amount of heat that is dissapated per tick
                }
            },

            UpgradeBlockStats = new Dictionary<string, UpgradeBlockStat>()
            {
                ["Example_UpgradeBlockStats"] = new UpgradeBlockStat()
                {
                    // these two are incompatible with eachother.
                    ApplyOnlyWhenFiring = false, // WEAPON BLOCKS ONLY. Makes all of the addons/multipliers apply only when the weapon is firing.
                    ApplyOnlyWhenOn = false, // FUNCTIONAL BLOCKS ONLY. Makes all of the addons/multipliers apply only if the block is functional.

                    PositionalErrorMultiplier = 1, // Positional error multiplier for ALL radars on the grid this is mounted on. Multipliers are calculated BEFORE addons.
                    PositionalErrorAddon = 0, // Positional error addon for ALL radars on the grid this is mounted on. Addons are calculated AFTER multipliers.

                    VelocityErrorMultiplier = 1, // Velocity error multiplier for ALL radars on the grid this is mounted on. Multipliers are calculated BEFORE addons.
                    VelocityErrorAddon = 0, // Velocity error addon for ALL radars on the grid this is mounted on. Addons are calculated AFTER multipliers.

                    NoiseFilterMultiplier = 1, // Noise filter multiplier for ALL radars on the grid this is mounted on. Multipliers are calculated BEFORE addons.
                    NoiseFilterAddon = 0, // Noise filter addon for ALL radars on the grid this is mounted on. Addons are calculated AFTER multipliers.

                    RCSMultiplier = 1, // RCS multiplier for the grid this is mounted on. Multipliers are calculated BEFORE addons.
                    RCSAddon = 0, //  RCS addon for the grid this is mounted on. Addons are calculated AFTER multipliers.

                    SensitivityMultiplier = 1, // Sensitivity multiplier for ALL radars on the grid this is mounted on. Multipliers are calculated BEFORE addons.
                    SensitivityAddon = 0, // Sensitivity addon for ALL radars on the grid this is mounted on. Addons are calculated AFTER multipliers.
                }
            },

            // IFF beacons are vanilla beacons which when placed on a grid, will replace the ship name given on its radar track with whatever its HUD name is set to.
            IFFBlockStats = new Dictionary<string, IFFBlockStat>()
            {
                ["LargeBlockIFFBeacon"] = new IFFBlockStat()
                {
                    MaxCharacters = 0, // maximum characters the IFF beacon will use
                    ShowClass = false, // whether or not the IFF beacon name change will completely replace (false) or only add its name after the class name (true)
                },
            }
        };
        // Do not touch below here
        public override void Init(MyObjectBuilder_SessionComponent sessionComponent)
        {
            byte[] data = MyAPIGateway.Utilities.SerializeToBinary(cfg);
            MyAPIGateway.Utilities.SendModMessage(DefConstants.MessageHandlerId, data);
        }
    }
}
